public interface Executable {
    public void run();
}
