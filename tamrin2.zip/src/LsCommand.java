
public class LsCommand implements Command {
    private FileManager fileManager;

    public LsCommand(FileManager fileManager) {
        this.fileManager = fileManager;
    }

    @Override
    public void execute(String[] args) {
        for (FileSystem child : fileManager.getCurrentDirectory().getChildren()) {
            System.out.println(child.getName());
        }
    }
}
