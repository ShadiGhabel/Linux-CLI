public interface Writable {
    public void write(String string);
}
