public interface Removable {
    public void remove();
}
