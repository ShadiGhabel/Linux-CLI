public interface Readable {
    public String read();
}
